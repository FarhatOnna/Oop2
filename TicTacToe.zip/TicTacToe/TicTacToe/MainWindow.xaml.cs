﻿// Name:            Farhat Rahman
// Program Name:    TicTacToe
// Date:            October 12th 2024
// Description:     This program lets users play tictactoe in wpf
//Resources: https://www.chatGPT.com
//Resources: https://www.stackoverflow.com
//Resources: https://www.youtube.com/watch?v=FA92dRdvNmA


using System.Windows;
using System.Windows.Controls;

namespace TicTacToe
{
    public partial class MainWindow : Window
    {
        private bool isXTurn = true; // Track whose turn it is (true = X, false = O)
        private int xPoints = 0;
        private int oPoints = 0;


        public MainWindow()
        {
            InitializeComponent();

  
        }



        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;

            // Check if the button has already been clicked
            if (btn.Content.ToString() == "")
            {
                btn.Content = isXTurn ? "X" : "O"; // Assign the current player's mark
                btn.IsEnabled = false; // Disable the button

                // Check for a winner or draw
                CheckWinner();
                isXTurn = !isXTurn; // Switch turns
            }
        }
        private void CheckWinner()
        {
            // Check rows, columns, and diagonals
            if (CheckLine(button1, button2, button3) ||
                CheckLine(button4, button5, button6) ||
                CheckLine(button7, button8, button9) ||
                CheckLine(button1, button4, button7) ||
                CheckLine(button2, button5, button8) ||
                CheckLine(button3, button6, button9) ||
                CheckLine(button1, button5, button9) ||
                CheckLine(button3, button5, button7))
            {
                string winner = isXTurn ? "X" : "O";
                MessageBox.Show($"{winner} Wins!", "Game Over", MessageBoxButton.OK, MessageBoxImage.Information);
                UpdateScore(winner);
                DisableAllButtons();
            }
            else if (IsDraw()) // Check for a draw
            {
                MessageBox.Show("It's a draw!", "Game Over", MessageBoxButton.OK, MessageBoxImage.Information);
            }

        }
        private bool CheckLine(Button b1, Button b2, Button b3)
        {
            return (b1.Content.ToString() != "" && b1.Content.ToString() == b2.Content.ToString() && b2.Content.ToString() == b3.Content.ToString());
        }

        private bool IsDraw()
        {
            // Check if all buttons are filled
            return button1.Content.ToString() != "" && button2.Content.ToString() != "" && button3.Content.ToString() != "" &&
                   button4.Content.ToString() != "" && button5.Content.ToString() != "" && button6.Content.ToString() != "" &&
                   button7.Content.ToString() != "" && button8.Content.ToString() != "" && button9.Content.ToString() != "";
        }
        private void DisableAllButtons()
        {
            foreach (Button btn in new[] { button1, button2, button3, button4, button5, button6, button7, button8, button9 })
            {
                btn.IsEnabled = false;
            }
        }
        //Update scores
        private void UpdateScore(string winner)
        {
            if (winner == "X")
            {
                xPoints++;
                xPointlb.Content = xPoints.ToString();
            }
            else
            {
                oPoints++;
                oPointsLb.Content = oPoints.ToString();
            }
        }
        private void ResetGame()
        {
            // Clear button content and enable all buttons
            foreach (Button btn in new[] { button1, button2, button3, button4, button5, button6, button7, button8, button9 })
            {
                btn.Content = "";
                btn.IsEnabled = true;
            }
            isXTurn = true; // Reset turn to X
        }

        private void reset_Btn_Click(object sender, RoutedEventArgs e)
        {
            ResetGame();
        }

        private void exit_Btn_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
